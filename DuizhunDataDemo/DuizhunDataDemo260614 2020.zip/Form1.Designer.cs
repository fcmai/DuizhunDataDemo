﻿namespace DuizhunDataDemo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>


        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            pictureBox1 = new PictureBox();
            btnStart = new Button();
            btn切换定时器使能 = new Button();
            lstLog = new ListBox();
            groupBox2 = new GroupBox();
            splitContainer1 = new SplitContainer();
            btn保存数据 = new Button();
            cbxParasSelect = new ComboBox();
            tab1 = new TabControl();
            tabPage1 = new TabPage();
            chk自动保存 = new CheckBox();
            panel13 = new Panel();
            lblCrossPoints = new Label();
            lblAngles = new Label();
            panel7 = new Panel();
            checkBox1 = new CheckBox();
            numericUpDown1 = new NumericUpDown();
            label12 = new Label();
            nudQuekouAngle = new NumericUpDown();
            label13 = new Label();
            panel5 = new Panel();
            label7 = new Label();
            panel4 = new Panel();
            nudRy = new NumericUpDown();
            nudRx = new NumericUpDown();
            label4 = new Label();
            btnDel = new Button();
            btnSaveParams = new Button();
            panel3 = new Panel();
            nudLy = new NumericUpDown();
            nudLx = new NumericUpDown();
            label3 = new Label();
            panel2 = new Panel();
            chk = new CheckBox();
            nudWaferErr = new NumericUpDown();
            label5 = new Label();
            nudWaferR = new NumericUpDown();
            label2 = new Label();
            panel10 = new Panel();
            nudWaferCy = new NumericUpDown();
            nudWaferCx = new NumericUpDown();
            label10 = new Label();
            panel9 = new Panel();
            nudDipanR = new NumericUpDown();
            label9 = new Label();
            panel11 = new Panel();
            nud旋转总角度 = new NumericUpDown();
            label11 = new Label();
            panel8 = new Panel();
            nudOmega = new NumericUpDown();
            label8 = new Label();
            panel6 = new Panel();
            nud线阵分辨率 = new NumericUpDown();
            label6 = new Label();
            panel1 = new Panel();
            nudCy = new NumericUpDown();
            nudCx = new NumericUpDown();
            label1 = new Label();
            tabPage2 = new TabPage();
            btnClose = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            tab1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel13.SuspendLayout();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudQuekouAngle).BeginInit();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudRy).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudRx).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudLy).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudLx).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudWaferErr).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudWaferR).BeginInit();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudWaferCy).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudWaferCx).BeginInit();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudDipanR).BeginInit();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nud旋转总角度).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudOmega).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nud线阵分辨率).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudCy).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudCx).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(192, 255, 192);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(731, 685);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "绘图窗口";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(3, 24);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(725, 657);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(1098, 55);
            btnStart.Margin = new Padding(3, 4, 3, 4);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(145, 41);
            btnStart.TabIndex = 4;
            btnStart.Text = "生成数据";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btn切换定时器使能
            // 
            btn切换定时器使能.Location = new Point(1098, 135);
            btn切换定时器使能.Margin = new Padding(3, 4, 3, 4);
            btn切换定时器使能.Name = "btn切换定时器使能";
            btn切换定时器使能.Size = new Size(145, 41);
            btn切换定时器使能.TabIndex = 4;
            btn切换定时器使能.Text = "切换定时器使能";
            btn切换定时器使能.UseVisualStyleBackColor = true;
            btn切换定时器使能.Click += btn切换定时器使能_Click;
            // 
            // lstLog
            // 
            lstLog.Dock = DockStyle.Fill;
            lstLog.FormattingEnabled = true;
            lstLog.Location = new Point(3, 24);
            lstLog.Margin = new Padding(3, 4, 3, 4);
            lstLog.Name = "lstLog";
            lstLog.Size = new Size(510, 657);
            lstLog.TabIndex = 5;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.FromArgb(192, 255, 255);
            groupBox2.Controls.Add(lstLog);
            groupBox2.Dock = DockStyle.Fill;
            groupBox2.Location = new Point(0, 0);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(516, 685);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "交点坐标";
            // 
            // splitContainer1
            // 
            splitContainer1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            splitContainer1.Location = new Point(23, 335);
            splitContainer1.Margin = new Padding(3, 4, 3, 4);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(groupBox2);
            splitContainer1.Size = new Size(1251, 685);
            splitContainer1.SplitterDistance = 731;
            splitContainer1.TabIndex = 7;
            // 
            // btn保存数据
            // 
            btn保存数据.Location = new Point(1098, 213);
            btn保存数据.Margin = new Padding(3, 4, 3, 4);
            btn保存数据.Name = "btn保存数据";
            btn保存数据.Size = new Size(145, 41);
            btn保存数据.TabIndex = 4;
            btn保存数据.Text = "保存数据";
            btn保存数据.UseVisualStyleBackColor = true;
            btn保存数据.Click += btnSaveToCsv_Click;
            // 
            // cbxParasSelect
            // 
            cbxParasSelect.FormattingEnabled = true;
            cbxParasSelect.Location = new Point(15, 29);
            cbxParasSelect.Margin = new Padding(4);
            cbxParasSelect.Name = "cbxParasSelect";
            cbxParasSelect.Size = new Size(116, 28);
            cbxParasSelect.TabIndex = 8;
            cbxParasSelect.SelectedIndexChanged += cbxParasSelect_SelectedIndexChanged;
            // 
            // tab1
            // 
            tab1.Controls.Add(tabPage1);
            tab1.Controls.Add(tabPage2);
            tab1.Location = new Point(27, 12);
            tab1.Margin = new Padding(4);
            tab1.Name = "tab1";
            tab1.SelectedIndex = 0;
            tab1.Size = new Size(1039, 315);
            tab1.TabIndex = 9;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(chk自动保存);
            tabPage1.Controls.Add(panel13);
            tabPage1.Controls.Add(panel7);
            tabPage1.Controls.Add(panel5);
            tabPage1.Controls.Add(panel4);
            tabPage1.Controls.Add(btnDel);
            tabPage1.Controls.Add(btnSaveParams);
            tabPage1.Controls.Add(panel3);
            tabPage1.Controls.Add(panel2);
            tabPage1.Controls.Add(panel10);
            tabPage1.Controls.Add(panel9);
            tabPage1.Controls.Add(panel11);
            tabPage1.Controls.Add(panel8);
            tabPage1.Controls.Add(panel6);
            tabPage1.Controls.Add(panel1);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(1031, 282);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "参数设置";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // chk自动保存
            // 
            chk自动保存.AutoSize = true;
            chk自动保存.ForeColor = Color.Blue;
            chk自动保存.Location = new Point(659, 231);
            chk自动保存.Margin = new Padding(4);
            chk自动保存.Name = "chk自动保存";
            chk自动保存.Size = new Size(159, 24);
            chk自动保存.TabIndex = 15;
            chk自动保存.Text = "自动保存输出到csv";
            chk自动保存.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            panel13.Controls.Add(lblCrossPoints);
            panel13.Controls.Add(lblAngles);
            panel13.Location = new Point(334, 184);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(287, 71);
            panel13.TabIndex = 14;
            // 
            // lblCrossPoints
            // 
            lblCrossPoints.AutoSize = true;
            lblCrossPoints.Location = new Point(8, 35);
            lblCrossPoints.Name = "lblCrossPoints";
            lblCrossPoints.Size = new Size(84, 20);
            lblCrossPoints.TabIndex = 2;
            lblCrossPoints.Text = "交点坐标：";
            // 
            // lblAngles
            // 
            lblAngles.AutoSize = true;
            lblAngles.Location = new Point(8, 11);
            lblAngles.Name = "lblAngles";
            lblAngles.Size = new Size(163, 20);
            lblAngles.TabIndex = 1;
            lblAngles.Text = "底盘转角： 缺口转角：";
            // 
            // panel7
            // 
            panel7.Controls.Add(checkBox1);
            panel7.Controls.Add(numericUpDown1);
            panel7.Controls.Add(label12);
            panel7.Controls.Add(nudQuekouAngle);
            panel7.Controls.Add(label13);
            panel7.Location = new Point(42, 184);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(287, 71);
            panel7.TabIndex = 11;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.ForeColor = Color.Blue;
            checkBox1.Location = new Point(202, 33);
            checkBox1.Margin = new Padding(4);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(61, 24);
            checkBox1.TabIndex = 3;
            checkBox1.Text = "启用";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            numericUpDown1.DecimalPlaces = 2;
            numericUpDown1.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            numericUpDown1.Location = new Point(123, 33);
            numericUpDown1.Margin = new Padding(3, 4, 3, 4);
            numericUpDown1.Maximum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.Minimum = new decimal(new int[] { 1, 0, 0, int.MinValue });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(72, 27);
            numericUpDown1.TabIndex = 2;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 131072 });
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(123, 11);
            label12.Name = "label12";
            label12.Size = new Size(69, 20);
            label12.TabIndex = 1;
            label12.Text = "随机偏差";
            // 
            // nudQuekouAngle
            // 
            nudQuekouAngle.DecimalPlaces = 2;
            nudQuekouAngle.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudQuekouAngle.Location = new Point(15, 33);
            nudQuekouAngle.Margin = new Padding(3, 4, 3, 4);
            nudQuekouAngle.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            nudQuekouAngle.Name = "nudQuekouAngle";
            nudQuekouAngle.Size = new Size(99, 27);
            nudQuekouAngle.TabIndex = 2;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(15, 9);
            label13.Name = "label13";
            label13.Size = new Size(69, 20);
            label13.TabIndex = 1;
            label13.Text = "缺口转角";
            // 
            // panel5
            // 
            panel5.Controls.Add(label7);
            panel5.Controls.Add(cbxParasSelect);
            panel5.Location = new Point(31, 18);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(156, 71);
            panel5.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(15, 6);
            label7.Name = "label7";
            label7.Size = new Size(99, 20);
            label7.TabIndex = 1;
            label7.Text = "参数方案选择";
            // 
            // panel4
            // 
            panel4.Controls.Add(nudRy);
            panel4.Controls.Add(nudRx);
            panel4.Controls.Add(label4);
            panel4.Location = new Point(795, 106);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(215, 71);
            panel4.TabIndex = 8;
            // 
            // nudRy
            // 
            nudRy.DecimalPlaces = 2;
            nudRy.Location = new Point(111, 33);
            nudRy.Margin = new Padding(3, 4, 3, 4);
            nudRy.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudRy.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudRy.Name = "nudRy";
            nudRy.Size = new Size(84, 27);
            nudRy.TabIndex = 2;
            nudRy.Value = new decimal(new int[] { 270, 0, 0, 0 });
            // 
            // nudRx
            // 
            nudRx.DecimalPlaces = 2;
            nudRx.Location = new Point(15, 33);
            nudRx.Margin = new Padding(3, 4, 3, 4);
            nudRx.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudRx.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudRx.Name = "nudRx";
            nudRx.Size = new Size(84, 27);
            nudRx.TabIndex = 2;
            nudRx.Value = new decimal(new int[] { 440, 0, 0, 0 });
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 9);
            label4.Name = "label4";
            label4.Size = new Size(84, 20);
            label4.TabIndex = 1;
            label4.Text = "线阵右端点";
            // 
            // btnDel
            // 
            btnDel.Location = new Point(861, 233);
            btnDel.Margin = new Padding(3, 4, 3, 4);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(145, 41);
            btnDel.TabIndex = 4;
            btnDel.Text = "删除当前参数";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnSaveParams
            // 
            btnSaveParams.Location = new Point(861, 185);
            btnSaveParams.Margin = new Padding(3, 4, 3, 4);
            btnSaveParams.Name = "btnSaveParams";
            btnSaveParams.Size = new Size(145, 41);
            btnSaveParams.TabIndex = 4;
            btnSaveParams.Text = "保存当前参数";
            btnSaveParams.UseVisualStyleBackColor = true;
            btnSaveParams.Click += btnSaveParams_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(nudLy);
            panel3.Controls.Add(nudLx);
            panel3.Controls.Add(label3);
            panel3.Location = new Point(559, 106);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(215, 71);
            panel3.TabIndex = 9;
            // 
            // nudLy
            // 
            nudLy.DecimalPlaces = 2;
            nudLy.Location = new Point(111, 33);
            nudLy.Margin = new Padding(3, 4, 3, 4);
            nudLy.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudLy.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudLy.Name = "nudLy";
            nudLy.Size = new Size(80, 27);
            nudLy.TabIndex = 2;
            nudLy.Value = new decimal(new int[] { 260, 0, 0, 0 });
            // 
            // nudLx
            // 
            nudLx.DecimalPlaces = 2;
            nudLx.Location = new Point(15, 33);
            nudLx.Margin = new Padding(3, 4, 3, 4);
            nudLx.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudLx.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudLx.Name = "nudLx";
            nudLx.Size = new Size(84, 27);
            nudLx.TabIndex = 2;
            nudLx.Value = new decimal(new int[] { 310, 0, 0, 0 });
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 9);
            label3.Name = "label3";
            label3.Size = new Size(84, 20);
            label3.TabIndex = 1;
            label3.Text = "线阵左端点";
            // 
            // panel2
            // 
            panel2.Controls.Add(chk);
            panel2.Controls.Add(nudWaferErr);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(nudWaferR);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(42, 106);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(287, 71);
            panel2.TabIndex = 10;
            // 
            // chk
            // 
            chk.AutoSize = true;
            chk.ForeColor = Color.Blue;
            chk.Location = new Point(202, 33);
            chk.Margin = new Padding(4);
            chk.Name = "chk";
            chk.Size = new Size(61, 24);
            chk.TabIndex = 3;
            chk.Text = "启用";
            chk.UseVisualStyleBackColor = true;
            // 
            // nudWaferErr
            // 
            nudWaferErr.DecimalPlaces = 2;
            nudWaferErr.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudWaferErr.Location = new Point(123, 33);
            nudWaferErr.Margin = new Padding(3, 4, 3, 4);
            nudWaferErr.Maximum = new decimal(new int[] { 1, 0, 0, 0 });
            nudWaferErr.Minimum = new decimal(new int[] { 1, 0, 0, int.MinValue });
            nudWaferErr.Name = "nudWaferErr";
            nudWaferErr.Size = new Size(72, 27);
            nudWaferErr.TabIndex = 2;
            nudWaferErr.Value = new decimal(new int[] { 1, 0, 0, 131072 });
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(123, 11);
            label5.Name = "label5";
            label5.Size = new Size(69, 20);
            label5.TabIndex = 1;
            label5.Text = "随机偏差";
            // 
            // nudWaferR
            // 
            nudWaferR.DecimalPlaces = 2;
            nudWaferR.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudWaferR.Location = new Point(15, 33);
            nudWaferR.Margin = new Padding(3, 4, 3, 4);
            nudWaferR.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            nudWaferR.Minimum = new decimal(new int[] { 100, 0, 0, 0 });
            nudWaferR.Name = "nudWaferR";
            nudWaferR.Size = new Size(99, 27);
            nudWaferR.TabIndex = 2;
            nudWaferR.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 9);
            label2.Name = "label2";
            label2.Size = new Size(69, 20);
            label2.TabIndex = 1;
            label2.Text = "晶圆半径";
            // 
            // panel10
            // 
            panel10.Controls.Add(nudWaferCy);
            panel10.Controls.Add(nudWaferCx);
            panel10.Controls.Add(label10);
            panel10.Location = new Point(334, 106);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(204, 71);
            panel10.TabIndex = 11;
            // 
            // nudWaferCy
            // 
            nudWaferCy.DecimalPlaces = 2;
            nudWaferCy.Location = new Point(102, 33);
            nudWaferCy.Margin = new Padding(3, 4, 3, 4);
            nudWaferCy.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudWaferCy.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudWaferCy.Name = "nudWaferCy";
            nudWaferCy.Size = new Size(90, 27);
            nudWaferCy.TabIndex = 2;
            nudWaferCy.Value = new decimal(new int[] { 300, 0, 0, 0 });
            // 
            // nudWaferCx
            // 
            nudWaferCx.DecimalPlaces = 2;
            nudWaferCx.Location = new Point(15, 33);
            nudWaferCx.Margin = new Padding(3, 4, 3, 4);
            nudWaferCx.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudWaferCx.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudWaferCx.Name = "nudWaferCx";
            nudWaferCx.Size = new Size(84, 27);
            nudWaferCx.TabIndex = 2;
            nudWaferCx.Value = new decimal(new int[] { 300, 0, 0, 0 });
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(15, 9);
            label10.Name = "label10";
            label10.Size = new Size(99, 20);
            label10.TabIndex = 1;
            label10.Text = "晶圆初始中心";
            // 
            // panel9
            // 
            panel9.Controls.Add(nudDipanR);
            panel9.Controls.Add(label9);
            panel9.Location = new Point(207, 18);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(145, 71);
            panel9.TabIndex = 3;
            // 
            // nudDipanR
            // 
            nudDipanR.DecimalPlaces = 2;
            nudDipanR.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudDipanR.Location = new Point(15, 33);
            nudDipanR.Margin = new Padding(3, 4, 3, 4);
            nudDipanR.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            nudDipanR.Name = "nudDipanR";
            nudDipanR.Size = new Size(87, 27);
            nudDipanR.TabIndex = 2;
            nudDipanR.Value = new decimal(new int[] { 180, 0, 0, 0 });
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(15, 9);
            label9.Name = "label9";
            label9.Size = new Size(69, 20);
            label9.TabIndex = 1;
            label9.Text = "底盘半径";
            // 
            // panel11
            // 
            panel11.Controls.Add(nud旋转总角度);
            panel11.Controls.Add(label11);
            panel11.Location = new Point(735, 18);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(127, 71);
            panel11.TabIndex = 4;
            // 
            // nud旋转总角度
            // 
            nud旋转总角度.Increment = new decimal(new int[] { 10, 0, 0, 0 });
            nud旋转总角度.Location = new Point(15, 33);
            nud旋转总角度.Margin = new Padding(3, 4, 3, 4);
            nud旋转总角度.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            nud旋转总角度.Name = "nud旋转总角度";
            nud旋转总角度.Size = new Size(84, 27);
            nud旋转总角度.TabIndex = 2;
            nud旋转总角度.Value = new decimal(new int[] { 720, 0, 0, 0 });
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(15, 9);
            label11.Name = "label11";
            label11.Size = new Size(84, 20);
            label11.TabIndex = 1;
            label11.Text = "旋转总角度";
            // 
            // panel8
            // 
            panel8.Controls.Add(nudOmega);
            panel8.Controls.Add(label8);
            panel8.Location = new Point(589, 18);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(127, 71);
            panel8.TabIndex = 5;
            // 
            // nudOmega
            // 
            nudOmega.DecimalPlaces = 2;
            nudOmega.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudOmega.Location = new Point(15, 33);
            nudOmega.Margin = new Padding(3, 4, 3, 4);
            nudOmega.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            nudOmega.Name = "nudOmega";
            nudOmega.Size = new Size(72, 27);
            nudOmega.TabIndex = 2;
            nudOmega.Value = new decimal(new int[] { 20, 0, 0, 0 });
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(15, 9);
            label8.Name = "label8";
            label8.Size = new Size(54, 20);
            label8.TabIndex = 1;
            label8.Text = "角速度";
            // 
            // panel6
            // 
            panel6.Controls.Add(nud线阵分辨率);
            panel6.Controls.Add(label6);
            panel6.Location = new Point(879, 18);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(127, 71);
            panel6.TabIndex = 6;
            // 
            // nud线阵分辨率
            // 
            nud线阵分辨率.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nud线阵分辨率.Location = new Point(15, 33);
            nud线阵分辨率.Margin = new Padding(3, 4, 3, 4);
            nud线阵分辨率.Maximum = new decimal(new int[] { 17000, 0, 0, 0 });
            nud线阵分辨率.Minimum = new decimal(new int[] { 1024, 0, 0, 0 });
            nud线阵分辨率.Name = "nud线阵分辨率";
            nud线阵分辨率.Size = new Size(87, 27);
            nud线阵分辨率.TabIndex = 2;
            nud线阵分辨率.Value = new decimal(new int[] { 4096, 0, 0, 0 });
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(15, 9);
            label6.Name = "label6";
            label6.Size = new Size(84, 20);
            label6.TabIndex = 1;
            label6.Text = "线阵分辨率";
            // 
            // panel1
            // 
            panel1.Controls.Add(nudCy);
            panel1.Controls.Add(nudCx);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(368, 18);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(204, 71);
            panel1.TabIndex = 7;
            // 
            // nudCy
            // 
            nudCy.DecimalPlaces = 2;
            nudCy.Location = new Point(102, 33);
            nudCy.Margin = new Padding(3, 4, 3, 4);
            nudCy.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudCy.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudCy.Name = "nudCy";
            nudCy.Size = new Size(90, 27);
            nudCy.TabIndex = 2;
            nudCy.Value = new decimal(new int[] { 250, 0, 0, 0 });
            // 
            // nudCx
            // 
            nudCx.DecimalPlaces = 2;
            nudCx.Location = new Point(15, 33);
            nudCx.Margin = new Padding(3, 4, 3, 4);
            nudCx.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudCx.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            nudCx.Name = "nudCx";
            nudCx.Size = new Size(84, 27);
            nudCx.TabIndex = 2;
            nudCx.Value = new decimal(new int[] { 250, 0, 0, 0 });
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 9);
            label1.Name = "label1";
            label1.Size = new Size(69, 20);
            label1.TabIndex = 1;
            label1.Text = "旋转中心";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 29);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(1031, 282);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "操作说明";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            btnClose.Location = new Point(1098, 282);
            btnClose.Margin = new Padding(3, 4, 3, 4);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(145, 41);
            btnClose.TabIndex = 4;
            btnClose.Text = "退出";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1300, 1042);
            Controls.Add(tab1);
            Controls.Add(splitContainer1);
            Controls.Add(btnStart);
            Controls.Add(btnClose);
            Controls.Add(btn保存数据);
            Controls.Add(btn切换定时器使能);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form 晶圆模拟对准数据生成测试";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            tab1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudQuekouAngle).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudRy).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudRx).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudLy).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudLx).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudWaferErr).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudWaferR).EndInit();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudWaferCy).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudWaferCx).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudDipanR).EndInit();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nud旋转总角度).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudOmega).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nud线阵分辨率).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudCy).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudCx).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox groupBox1;
        private PictureBox pictureBox1;
        private Button btnStart;
        private TextBox textBox1;
        private Button btn切换定时器使能;
        private ListBox lstLog;
        private GroupBox groupBox2;
        private SplitContainer splitContainer1;
        private Button btn保存数据;
        private ComboBox cbxParasSelect;
        private TabControl tab1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Panel panel4;
        private NumericUpDown nudRy;
        private NumericUpDown nudRx;
        private Label label4;
        private Panel panel3;
        private NumericUpDown nudLy;
        private NumericUpDown nudLx;
        private Label label3;
        private Panel panel2;
        private CheckBox chk;
        private NumericUpDown nudWaferErr;
        private Label label5;
        private NumericUpDown nudWaferR;
        private Label label2;
        private Panel panel10;
        private NumericUpDown nudWaferCy;
        private NumericUpDown nudWaferCx;
        private Label label10;
        private Panel panel9;
        private NumericUpDown nudDipanR;
        private Label label9;
        private Panel panel11;
        private NumericUpDown nud旋转总角度;
        private Label label11;
        private Panel panel8;
        private NumericUpDown nudOmega;
        private Label label8;
        private Panel panel6;
        private NumericUpDown nud线阵分辨率;
        private Label label6;
        private Panel panel1;
        private NumericUpDown nudCy;
        private NumericUpDown nudCx;
        private Label label1;
        private Button btnClose;
        private Panel panel5;
        private Label label7;
        private Panel panel7;
        private CheckBox checkBox1;
        private NumericUpDown numericUpDown1;
        private Label label12;
        private NumericUpDown nudQuekouAngle;
        private Label label13;
        private Panel panel13;
        private Label lblAngles;
        private Label lblCrossPoints;
        private Button btnSaveParams;
        private Button btnDel;
        private CheckBox chk自动保存;
    }
}
